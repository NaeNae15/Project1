from django.urls import path
from .views import indexPageView, menuPageView, FAQPageView, aboutPageView
            
urlpatterns = [
    path("", indexPageView, name="index"),
    path('menu/', menuPageView, name = 'menu'),
    path('FAQ/', FAQPageView, name = 'FAQ'),
    path('about/', aboutPageView, name = 'about'),
    ]