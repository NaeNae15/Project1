from django.http import HttpResponse

# Create your views here.

from django.http import HttpResponse

# Create your views here.
def indexPageView(request) :
    return HttpResponse('SourdoughHouse')

def menuPageView(request) :
    return HttpResponse('Menu')

def FAQPageView(request) :
    return HttpResponse('FAQ')

def aboutPageView(request) :
    return HttpResponse('About')